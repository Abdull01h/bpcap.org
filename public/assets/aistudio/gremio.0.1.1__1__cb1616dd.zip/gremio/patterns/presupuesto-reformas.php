<?php
/**
 * Title: Renovations · Quote by line item
 * Slug: gremio/presupuesto-reformas
 * Categories: gremio-piezas
 * Description: What makes the renovations landing page different: the quote with the measurements behind it and a few examples of what each job costs, with its days. The figures are examples for the demo: the renovator who buys the theme uses their own.
 * Keywords: renovations, quote, prices, line items, measurements
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"fondo","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull has-fondo-background-color has-background" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'What a renovation costs, with the measurements in hand', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'These are examples of jobs we have done, with the days they took. Your quote will be similar if your home is similar: if not, it is measured and said.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"backgroundColor":"claro","style":{"spacing":{"margin":{"top":"36px"},"padding":{"top":"30px","bottom":"30px","left":"34px","right":"34px"}},"border":{"radius":"12px","width":"1px","color":"rgba(0,0,0,0.07)"}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.07);border-width:1px;border-radius:12px;margin-top:36px;padding-top:30px;padding-right:34px;padding-bottom:30px;padding-left:34px">
		<!-- wp:list -->
		<ul class="wp-block-list">
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>4 m² bathroom, full renovation with materials:</strong> 4.800 – 6.500 € · about 10 days of work', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>12 m² kitchen, without units or appliances:</strong> 6.500 – 9.500 € · about 3 weeks', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>80 m² flat, full renovation:</strong> 950 – 1.400 €/m² depending on finishes · 6 to 10 weeks', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>60 m² shop unit, renovation to open:</strong> from 700 €/m² · 4 to 6 weeks', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Work in phases, so the business does not have to close:</strong> each phase is quoted and can be paid in stages', 'gremio' ) ); ?></li><!-- /wp:list-item -->
		</ul>
		<!-- /wp:list -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
		<p style="font-size:15px"><?php esc_html_e( 'The quote goes by line item with the measurements behind it: anything not on the list is not charged. If something unseen turns up when we open (a broken pipe, an unearthed consumer unit), we stop, let you know and quote it separately before doing it.', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"28px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:28px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Have my home measured', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
