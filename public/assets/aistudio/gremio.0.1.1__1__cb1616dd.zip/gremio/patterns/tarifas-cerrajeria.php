<?php
/**
 * Title: Locksmithing · Published price list
 * Slug: gremio/tarifas-cerrajeria
 * Categories: gremio-piezas
 * Description: What makes the locksmithing landing page different: the prices, published and given on the phone before setting off. The figures are examples for the demo (the locksmith who buys the theme uses their own).
 * Keywords: locksmithing, prices, price list, no surprises
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"fondo","style":{"spacing":{"padding":{"top":"80px","bottom":"80px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull has-fondo-background-color has-background" style="padding-top:80px;padding-bottom:80px">
	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'Published price list, no surprises', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'The same for everyone, given on the phone and written on the invoice. If your case is not here, we give you a price before we set off.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"backgroundColor":"claro","style":{"spacing":{"margin":{"top":"36px"},"padding":{"top":"30px","bottom":"30px","left":"34px","right":"34px"}},"border":{"radius":"12px","width":"1px","color":"rgba(0,0,0,0.07)"}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.07);border-width:1px;border-radius:12px;margin-top:36px;padding-top:30px;padding-right:34px;padding-bottom:30px;padding-left:34px">
		<!-- wp:list -->
		<ul class="wp-block-list">
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Lockout, daytime on a working day:</strong> from 60 €', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Night-time lockout, weekend or public holiday:</strong> from 90 €', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Lock cylinder change:</strong> 45 € labour, security lock cylinder from 25 €', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Multipoint lock or anti-bumping shield:</strong> quote on site, the visit is not charged', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Metal shop shutter:</strong> from 120 €, with the part fitted the same day if we have it', 'gremio' ) ); ?></li><!-- /wp:list-item -->
		</ul>
		<!-- /wp:list -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
		<p style="font-size:15px"><?php esc_html_e( 'The call-out is not charged if you accept the quote. If something unseen turns up when we open, we stop, call and decide it with you.', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"28px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:28px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Call and ask about your case', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
