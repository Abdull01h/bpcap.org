<?php
/**
 * Title: Renovation · Before and after
 * Slug: gremio/antes-despues-reformas
 * Categories: gremio-piezas
 * Description: The work showcase on the renovation home page: two finished renovations with their photo from the start —the bathroom (a real pair, from the old photos) and the living room (the before was generated image-to-image from the real photo)— and what was done in each, with the days of building work. To add another pair, copy the columns block. It was also tried with the kitchen and dropped: the after was already in dark wood and the pair could not be told apart.
 * Keywords: renovation, before and after, building work, kitchen, bathroom
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-2-color has-text-color" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Before and after', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'Two finished renovations, with the photo from day one', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'The photo on the left is what we found when we walked in (and the one the client sends for the first quote). On the right, the same room finished, with the days of building work it took.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px","fontWeight":"700","letterSpacing":"0.1em","textTransform":"uppercase"}},"textColor":"texto"} -->
			<p class="has-texto-color has-text-color" style="font-size:14px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase"><?php esc_html_e( 'Before', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"12px"}}} -->
			<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/bano-antes.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Bathroom before the renovation: old bathtub and green tiles', 'gremio' ); ?>" style="border-radius:12px"/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
			<p style="font-size:15px"><?php esc_html_e( '4 m² bathroom · 80s bathtub, green tiles and lead pipework.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px","fontWeight":"700","letterSpacing":"0.1em","textTransform":"uppercase"}},"textColor":"acento-2"} -->
			<p class="has-acento-2-color has-text-color" style="font-size:14px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase"><?php esc_html_e( 'After', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"12px"}}} -->
			<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/bano-despues.jpg' ) ); ?>" alt="<?php esc_attr_e( 'The same bathroom renovated: tiled shower tray, screen and vanity unit', 'gremio' ); ?>" style="border-radius:12px"/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
			<p style="font-size:15px"><?php esc_html_e( 'Tiled shower tray, screen, vanity unit and new tiling. Plumbing and electrics replaced.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"36px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:36px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px","fontWeight":"700","letterSpacing":"0.1em","textTransform":"uppercase"}},"textColor":"texto"} -->
			<p class="has-texto-color has-text-color" style="font-size:14px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase"><?php esc_html_e( 'Before', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"12px"}}} -->
			<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/obra-1-antes.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Living room before the renovation: old carpet, wallpaper and an old radiator', 'gremio' ); ?>" style="border-radius:12px"/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
			<p style="font-size:15px"><?php esc_html_e( '22 m² living room · 90s carpet, peeling wallpaper and a radiator that gave no heat.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px","fontWeight":"700","letterSpacing":"0.1em","textTransform":"uppercase"}},"textColor":"acento-2"} -->
			<p class="has-acento-2-color has-text-color" style="font-size:14px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase"><?php esc_html_e( 'After', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"12px"}}} -->
			<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/obra-1.jpg' ) ); ?>" alt="<?php esc_attr_e( 'The same living room renovated: new floor, smoothed walls and natural light', 'gremio' ); ?>" style="border-radius:12px"/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
			<p style="font-size:15px"><?php esc_html_e( 'New floor, smoothed walls, new radiator and the wiring brought up to date. Four weeks of building work.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"36px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:36px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="#presupuesto"><?php esc_html_e( 'Send my photos and book a measuring visit', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->