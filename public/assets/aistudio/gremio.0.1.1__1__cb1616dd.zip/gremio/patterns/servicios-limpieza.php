<?php
/**
 * Title: Cleaning · Services
 * Slug: gremio/servicios-limpieza
 * Categories: gremio-piezas
 * Description: The six cleaning jobs, with the style and colours of the reasons band (no boxes, 38 px icons in the dark accent). They run from the home to the communal entrance, the office, the windows, the post-construction clean and upholstery.
 * Keywords: cleaning, services, home, office, communal, windows, upholstery
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-2-color has-text-color" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'What we do', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'From the home to the communal entrance, with the same people', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'Regular maintenance cleaning and one-off cleans you only need once: post-construction, a move or getting the place ready for a viewing.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 11 12 4l9 7"/><path d="M5 10v10h14V10"/><path d="M10 20v-6h4v6"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Homes', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Weekly or fortnightly: floors, bathrooms, kitchen, dusting and inside windows. We agree a list of priorities and stick to the order.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="12" rx="1.5"/><path d="M8 20h8"/><path d="M12 16v4"/><path d="M7 8h5M7 12h8"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Offices and premises', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Before the team arrives or after they leave, so we don\'t get in the way. Bins, bathrooms, floors, windows and the office kitchen.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20V8h5v12"/><path d="M9 20V6h6v14"/><path d="M15 20v-9h5v9"/><path d="M3 20h18"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Communal entrances, stairwells and blocks', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Sweeping and mopping floor by floor, handrails, windows and rubbish chutes, with the task sheet for each visit signed and available to the residents.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"36px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:36px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="1.5"/><path d="M3 12h18M12 3v18"/><path d="M15 7h2"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Windows', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Windows, frames and shutters, inside and out as far as the pole reaches. Water with neutral soap and drying with a squeegee: no scratches, no streaks.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 20h18"/><path d="M5 20v-5l4-3 6 3 4-2v7"/><path d="M9 12V6a2 2 0 0 1 4 0v4"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Post-construction clean', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Building dust, bits of plaster and cement, paint splashes and a final polish. Done after the last trade and before handing over the house.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 12V9a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v3"/><path d="M4 12h16v4H4z"/><path d="M7 16v3M17 16v3"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Sofas, rugs and upholstery', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Injection-extraction cleaning for sofas, mattresses and carpets, with fast drying. We test a corner first so you see the result before we carry on.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
