<?php
/**
 * Title: Carpentry · Services
 * Slug: gremio/servicios-carpinteria
 * Categories: gremio-piezas
 * Description: The six carpentry jobs, with the style and colours of the reasons band (no boxes, 38 px icons in the dark accent). The headline goes as a sentence, not as a label.
 * Keywords: carpentry, services, doors, wardrobes, windows, flooring, varnishing
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-2-color has-text-color" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'What we do', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'We measure it, we make it and we fit it ourselves', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'From the opening to the finished furniture. Everything comes out of our workshop and is fitted in your home on the day we said.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 21V4a1 1 0 0 1 1-1h9a1 1 0 0 1 1 1v17"/><path d="M15 9h4a1 1 0 0 1 1 1v11"/><path d="M2 21h20"/><circle cx="12" cy="12" r="1"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Interior and entrance doors', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Doors, entrance doors and built-in wardrobes. We take the measurements at your home and make them in the workshop, with the ironmongery and finish you choose.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="2" width="18" height="20" rx="1.5"/><path d="M12 2v20"/><path d="M10 12h.01M14 12h.01"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Made-to-measure wardrobes and walk-in closets', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'From the opening to a ceiling put to use. Sliding or hinged doors, made-to-measure drawers and the layout planned around what you\'re going to store.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="1.5"/><path d="M12 3v18M3 12h18"/><path d="M7 7h2M15 17h2"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Wooden windows and doors', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Wooden windows with double glazing and new glazing beads. If the external woodwork is sound, we restore it; if not, we replace it to the same measurements.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"36px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:36px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="4" width="20" height="15" rx="1.5"/><path d="M2 12h20"/><path d="M7 8h3M7 16h4M15 12v7M9 12v7"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Kitchen and fitted furniture', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Base and wall units, worktops and wooden fronts, with the gaps measured for your appliances and the finish tight to the wall.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="2" y="5" width="20" height="14" rx="1.5"/><path d="M7 5v14M12 5v14M17 5v14"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Floors and wooden flooring', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Solid or engineered wooden flooring, nailed or floating. And if the floor you already have is sound: we sand it, fill whatever\'s there and varnish it.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20V7a1 1 0 0 1 1-1h9l3 3v11"/><path d="M4 20h16"/><path d="M8 10h4M8 14h4"/><path d="M20 6l1.5 1.5"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Restoration and varnishing', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Family furniture, old doors and mouldings: cleaned, dents repaired and varnished or lacquered in the colour you want.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
