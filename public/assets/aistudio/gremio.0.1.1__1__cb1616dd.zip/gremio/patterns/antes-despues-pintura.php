<?php
/**
 * Title: Painting and decorating · Before and after
 * Slug: gremio/antes-despues-pintura
 * Categories: gremio-piezas
 * Description: What makes the painting and decorating landing page different: the same wall before and after, with the work explained below. The "before" was generated from the theme's real "after" (Kie starting image) so that it is the same room and the same light, not two different photos. To add more pairs, copy the pair of columns.
 * Keywords: painting and decorating, before and after, works, walls
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-2-color has-text-color" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Before and after', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'The same wall, two days of work apart', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'No touching up: this is how a wall with damp and cracks looks after being repaired, primed and given two coats. The photo on the left is the one you send for a quote.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px","fontWeight":"700","letterSpacing":"0.1em","textTransform":"uppercase"}},"textColor":"texto"} -->
			<p class="has-texto-color has-text-color" style="font-size:14px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase"><?php esc_html_e( 'Before', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"12px"}}} -->
			<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/pintura-piso-antes.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Living room before painting: wall with damp, cracks and patched plaster', 'gremio' ); ?>" style="border-radius:12px"/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
			<p style="font-size:15px"><?php esc_html_e( 'A 20 m² living room · damp, cracks and the patched plaster of an earlier job.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"14px","fontWeight":"700","letterSpacing":"0.1em","textTransform":"uppercase"}},"textColor":"acento-2"} -->
			<p class="has-acento-2-color has-text-color" style="font-size:14px;font-weight:700;letter-spacing:0.1em;text-transform:uppercase"><?php esc_html_e( 'After', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"12px"}}} -->
			<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/pintura-piso-vacio.jpg' ) ); ?>" alt="<?php esc_attr_e( 'The same living room after filling and skimming, priming and painting', 'gremio' ); ?>" style="border-radius:12px"/></figure>
			<!-- /wp:image -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
			<p style="font-size:15px"><?php esc_html_e( 'Filling and skimming, primer and two coats of washable matt emulsion. Floor protected and sockets covered.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"36px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:36px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="#presupuesto"><?php esc_html_e( 'Send my photo and get a price', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
