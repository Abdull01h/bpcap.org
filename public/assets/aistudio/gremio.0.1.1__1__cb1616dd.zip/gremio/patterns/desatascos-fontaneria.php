<?php
/**
 * Title: Plumbing · Blocked drains with prices
 * Slug: gremio/desatascos-fontaneria
 * Categories: gremio-piezas
 * Description: What people bring to a plumber, with an indicative price published (blocked drains, camera and out-of-hours surcharge). The amounts are examples for the demo: the plumber who buys the theme sets their own.
 * Keywords: plumbing, blocked drains, prices, indicative, emergency call-out
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"fondo","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull has-fondo-background-color has-background" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'Blocked drains: what it costs, before we come', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'Prices are given over the phone and are indicative: they\'re confirmed once we see the blockage and nothing is touched without telling you the amount first.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"backgroundColor":"claro","style":{"spacing":{"margin":{"top":"36px"},"padding":{"top":"30px","bottom":"30px","left":"34px","right":"34px"}},"border":{"radius":"12px","width":"1px","color":"rgba(0,0,0,0.07)"}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.07);border-width:1px;border-radius:12px;margin-top:36px;padding-top:30px;padding-right:34px;padding-bottom:30px;padding-left:34px">
		<!-- wp:list -->
		<ul class="wp-block-list">
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Blocked sink, washbasin or bidet:</strong> 60 – 90 € · on the same visit', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Blocked toilet:</strong> 80 – 120 € · with a machine if needed', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Soil stack or drain with a machine:</strong> 150 – 260 € · depending on the metres and the access points', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Camera inspection and locating the blockage:</strong> 90 – 140 € · deducted from the drain clearing if we do the work', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Out-of-hours emergency call-out:</strong> 40 % surcharge on the rate, given over the phone before we set off', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>If the floor has to be lifted or something broken:</strong> we stop, explain it with the camera in front of you and quote it separately', 'gremio' ) ); ?></li><!-- /wp:list-item -->
		</ul>
		<!-- /wp:list -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
		<p style="font-size:15px"><?php esc_html_e( 'The price includes the call-out and standard materials. Before you call, a tip that saves money: off-the-shelf chemicals and wire rods tend to break the seal and push the blockage further in — it\'s the breakdown that then costs twice as much.', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"28px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:28px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Tell you what\'s happening', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->