<?php
/**
 * Title: Locksmithing · Anti-scam notice
 * Slug: gremio/aviso-cerrajeria
 * Categories: gremio-piezas
 * Description: The other thing that is specific to locksmithing: the notice against those who charge 300 € for a lockout. It sits on the ink band (not in the footer, where it is not read) and says what a customer can demand from any locksmith, ourselves included.
 * Keywords: locksmithing, notice, scam, trust
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"tinta","textColor":"claro","style":{"spacing":{"padding":{"top":"80px","bottom":"80px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull has-claro-color has-tinta-background-color has-text-color has-background" style="padding-top:80px;padding-bottom:80px">
	<!-- wp:group {"layout":{"type":"constrained","contentSize":"820px","justifyContent":"left"}} -->
	<div class="wp-block-group">
		<!-- wp:heading {"textColor":"acento"} -->
		<h2 class="wp-block-heading has-acento-color has-text-color"><?php esc_html_e( 'How to tell you are not being ripped off', 'gremio' ); ?></h2>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
		<p class="has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'Some people in this trade charge 300 € to open a door in five minutes. These three things you can demand from any locksmith, and from us too:', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:list {"style":{"typography":{"fontSize":"17px"}},"textColor":"claro"} -->
		<ul class="wp-block-list has-claro-color has-text-color" style="font-size:17px">
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>A price on the phone before they come out.</strong> If they will not give you one, it is not a local locksmith.', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Their ID and an invoice with a tax number.</strong> A serious locksmith gives you their name and their company, and invoices you with VAT.', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>No cash-only payment and no signing a blank job sheet.</strong> The work is invoiced, and the price is clear before we start.', 'gremio' ) ); ?></li><!-- /wp:list-item -->
		</ul>
		<!-- /wp:list -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"17px"}},"textColor":"claro"} -->
		<p class="has-claro-color has-text-color" style="font-size:17px"><?php esc_html_e( 'If someone asks you that kind of money to open your door, they are not one of us: call us and we will tell you what it really costs.', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:buttons -->
		<div class="wp-block-buttons">
			<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
			<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Call now', 'gremio' ); ?></a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->
</div>
<!-- /wp:group -->
