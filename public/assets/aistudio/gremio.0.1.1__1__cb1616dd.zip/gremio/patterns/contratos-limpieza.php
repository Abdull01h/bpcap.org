<?php
/**
 * Title: Cleaning · The three contracts
 * Slug: gremio/contratos-limpieza
 * Categories: gremio-piezas
 * Description: What is specific to this trade: the three ways to hire it (home, office and communal building) with the hours upfront and what is included in each. The figures are examples for the demo: the company that buys the theme puts in its own. Three white cards on the soft background band.
 * Keywords: cleaning, contracts, prices, home, office, communal building
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"fondo","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull has-fondo-background-color has-background" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'Three ways to hire it, with the hours upfront', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'You are charged by hours worked, not for "a clean". That way you know what each month will cost and you can add or cut hours without renegotiating anything.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"backgroundColor":"claro","style":{"spacing":{"padding":{"top":"28px","bottom":"28px","left":"26px","right":"26px"}},"border":{"radius":"12px","width":"1px","color":"rgba(0,0,0,0.07)"}}} -->
			<div class="wp-block-group has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.07);border-width:1px;border-radius:12px;padding-top:28px;padding-right:26px;padding-bottom:28px;padding-left:26px">
				<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"21px"}}} -->
				<h3 class="wp-block-heading" style="font-size:21px"><?php esc_html_e( 'Home', 'gremio' ); ?></h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"style":{"typography":{"fontSize":"17px","fontWeight":"700"}},"textColor":"acento-2"} -->
				<p class="has-acento-2-color has-text-color" style="font-size:17px;font-weight:700"><?php esc_html_e( 'From 17 €/hour · 3 or 4 hours per visit', 'gremio' ); ?></p>
				<!-- /wp:paragraph -->
				<!-- wp:list -->
				<ul class="wp-block-list">
					<!-- wp:list-item --><li><?php esc_html_e( 'Weekly, fortnightly or only when you need it.', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'The same person every time: they know the home and what not to touch.', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'Materials included (if you want a specific product, we use yours).', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'Monthly invoice and no fixed-term contract.', 'gremio' ); ?></li><!-- /wp:list-item -->
				</ul>
				<!-- /wp:list -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"backgroundColor":"claro","style":{"spacing":{"padding":{"top":"28px","bottom":"28px","left":"26px","right":"26px"}},"border":{"radius":"12px","width":"1px","color":"rgba(0,0,0,0.07)"}}} -->
			<div class="wp-block-group has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.07);border-width:1px;border-radius:12px;padding-top:28px;padding-right:26px;padding-bottom:28px;padding-left:26px">
				<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"21px"}}} -->
				<h3 class="wp-block-heading" style="font-size:21px"><?php esc_html_e( 'Office and premises', 'gremio' ); ?></h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"style":{"typography":{"fontSize":"17px","fontWeight":"700"}},"textColor":"acento-2"} -->
				<p class="has-acento-2-color has-text-color" style="font-size:17px;font-weight:700"><?php esc_html_e( 'From 19 €/hour · before or after opening hours', 'gremio' ); ?></p>
				<!-- /wp:paragraph -->
				<!-- wp:list -->
				<ul class="wp-block-list">
					<!-- wp:list-item --><li><?php esc_html_e( 'Days and tasks in writing, in a monthly contract.', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'A task sheet signed on every visit (a copy is available on request).', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'One contact person for notices and absences.', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'Staff registered and covered by public liability insurance.', 'gremio' ); ?></li><!-- /wp:list-item -->
				</ul>
				<!-- /wp:list -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"backgroundColor":"claro","style":{"spacing":{"padding":{"top":"28px","bottom":"28px","left":"26px","right":"26px"}},"border":{"radius":"12px","width":"1px","color":"rgba(0,0,0,0.07)"}}} -->
			<div class="wp-block-group has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.07);border-width:1px;border-radius:12px;padding-top:28px;padding-right:26px;padding-bottom:28px;padding-left:26px">
				<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"21px"}}} -->
				<h3 class="wp-block-heading" style="font-size:21px"><?php esc_html_e( 'Communal building and entrance', 'gremio' ); ?></h3>
				<!-- /wp:heading -->
				<!-- wp:paragraph {"style":{"typography":{"fontSize":"17px","fontWeight":"700"}},"textColor":"acento-2"} -->
				<p class="has-acento-2-color has-text-color" style="font-size:17px;font-weight:700"><?php esc_html_e( 'Quote per entrance · from 260 €/month', 'gremio' ); ?></p>
				<!-- /wp:paragraph -->
				<!-- wp:list -->
				<ul class="wp-block-list">
					<!-- wp:list-item --><li><?php esc_html_e( 'Sweeping and mopping on every floor, handrails and rubbish chutes.', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'Windows and entrance doors on their own schedule.', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'Can be arranged through the property manager or directly with the residents.', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'If one day cannot be done, we let you know and make it up another day at no extra charge.', 'gremio' ); ?></li><!-- /wp:list-item -->
				</ul>
				<!-- /wp:list -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"36px"}},"typography":{"fontSize":"17px"}}} -->
	<p class="has-text-align-center" style="margin-top:36px;font-size:17px"><?php esc_html_e( 'The figures are examples until we see the home or the premises: the real hours are worked out on the first visit. If the task sheet is not met, we put it right at no charge.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"24px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:24px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Get my hours worked out', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
