<?php
/**
 * Title: Home page — Heating and Air Conditioning
 * Slug: gremio/portada-climatizacion
 * Categories: gremio-portadas
 * Description: Complete heating and air conditioning home page: hero, what we do, the two campaigns (installation and maintenance), the efficiency band, why choose us, reviews and contact. The generic pieces (reasons and contact) are called as they are.
 * Keywords: home page, hvac, start, trade, aerothermal
 */
?>
<!-- wp:pattern {"slug":"gremio/heroe-climatizacion"} /-->

<!-- wp:pattern {"slug":"gremio/servicios-climatizacion"} /-->

<!-- wp:pattern {"slug":"gremio/campanas-climatizacion"} /-->

<!-- wp:pattern {"slug":"gremio/eficiencia-climatizacion"} /-->

<!-- wp:pattern {"slug":"gremio/razones"} /-->

<!-- wp:pattern {"slug":"gremio/opiniones-climatizacion"} /-->

<!-- wp:pattern {"slug":"gremio/contacto"} /-->
