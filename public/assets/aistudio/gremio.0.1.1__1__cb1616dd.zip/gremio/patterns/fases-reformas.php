<?php
/**
 * Title: Renovation · The stages and the lead times
 * Slug: gremio/fases-reformas
 * Categories: gremio-piezas
 * Description: The four stages of a job, with what happens in each one and when you know how long it will take. The numbers are in the dark accent because here they really are a sequence (unlike the reasons band, which is not).
 * Keywords: renovation, stages, lead times, schedule
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-2-color has-text-color" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'How we work', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'When you know how long your renovation will take', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'Before moving a single partition wall: the completion date is signed with the quote, not promised over the phone.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"30px","fontWeight":"700"}},"textColor":"acento-2","fontFamily":"titulos"} -->
			<p class="has-acento-2-color has-text-color has-titulos-font-family" style="font-size:30px;font-weight:700">01</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Visit and measurements', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'We come to your home, take measurements and check what is out of sight: the pipework, the fuse board, damp from the flat above. The visit is free.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"30px","fontWeight":"700"}},"textColor":"acento-2","fontFamily":"titulos"} -->
			<p class="has-acento-2-color has-text-color has-titulos-font-family" style="font-size:30px;font-weight:700">02</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Itemised quote', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Backed by the measurements: masonry, plumbing, electrics and finishes, each item with its price and its lead time. You can see where every euro goes.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"30px","fontWeight":"700"}},"textColor":"acento-2","fontFamily":"titulos"} -->
			<p class="has-acento-2-color has-text-color has-titulos-font-family" style="font-size:30px;font-weight:700">03</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Signed schedule', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'A schedule with each trade coming in and the completion date, signed alongside the quote. If it slips, we tell you that same day, not at the end.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"30px","fontWeight":"700"}},"textColor":"acento-2","fontFamily":"titulos"} -->
			<p class="has-acento-2-color has-text-color has-titulos-font-family" style="font-size:30px;font-weight:700">04</p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Handover and final check', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'We walk the job with you, note down anything missing and finish it off before the final invoice. Two-year guarantee on labour.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->