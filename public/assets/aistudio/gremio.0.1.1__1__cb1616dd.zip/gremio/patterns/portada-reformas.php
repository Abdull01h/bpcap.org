<?php
/**
 * Title: Home page — Renovation
 * Slug: gremio/portada-reformas
 * Categories: gremio-portadas
 * Description: Complete renovation home page: hero, what we do, before and after (bathroom and kitchen), the phases and timelines, quote by line items, why choose us, reviews and contact.
 * Keywords: home page, renovation, start, trade, works
 */
?>
<!-- wp:pattern {"slug":"gremio/heroe-reformas"} /-->

<!-- wp:pattern {"slug":"gremio/servicios-reformas"} /-->

<!-- wp:pattern {"slug":"gremio/antes-despues-reformas"} /-->

<!-- wp:pattern {"slug":"gremio/fases-reformas"} /-->

<!-- wp:pattern {"slug":"gremio/presupuesto-reformas"} /-->

<!-- wp:pattern {"slug":"gremio/razones"} /-->

<!-- wp:pattern {"slug":"gremio/opiniones-reformas"} /-->

<!-- wp:pattern {"slug":"gremio/contacto"} /-->
