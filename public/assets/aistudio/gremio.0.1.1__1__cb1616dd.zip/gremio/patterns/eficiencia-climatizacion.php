<?php
/**
 * Title: Heating and air conditioning · Efficiency
 * Slug: gremio/eficiencia-climatizacion
 * Categories: gremio-piezas
 * Description: The four figures that explain why a unit uses too much, on the ink band with the numbers in lime. It is the other argument specific to heating and air conditioning: it is not fixed by buying expensive, it is fixed by sizing well and servicing.
 * Keywords: heating and air conditioning, efficiency, consumption, energy label, filters
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"tinta","textColor":"claro","style":{"spacing":{"padding":{"top":"80px","bottom":"80px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull has-claro-color has-tinta-background-color has-text-color has-background" style="padding-top:80px;padding-bottom:80px">
	<!-- wp:heading {"textAlign":"center","textColor":"acento"} -->
	<h2 class="wp-block-heading has-text-align-center has-acento-color has-text-color"><?php esc_html_e( 'How much it really costs to run', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'The four figures that explain why a unit uses too much. None of them is fixed by buying an expensive one: you fix it by choosing well and keeping it serviced.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"28px","left":"28px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"34px","fontWeight":"700"}},"textColor":"acento","fontFamily":"titulos"} -->
			<p class="has-acento-color has-text-color has-titulos-font-family" style="font-size:34px;font-weight:700"><?php esc_html_e( 'A+++', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:16px"><?php esc_html_e( 'The energy label is what tells you how much it will use; the brand, much less than it seems.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"34px","fontWeight":"700"}},"textColor":"acento","fontFamily":"titulos"} -->
			<p class="has-acento-color has-text-color has-titulos-font-family" style="font-size:34px;font-weight:700">15 %</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:16px"><?php esc_html_e( 'How much more a unit can use with dirty filters and a dust-filled coil.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"34px","fontWeight":"700"}},"textColor":"acento","fontFamily":"titulos"} -->
			<p class="has-acento-color has-text-color has-titulos-font-family" style="font-size:34px;font-weight:700">5-8 %</p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:16px"><?php esc_html_e( 'What it adds to the bill for every degree you lower the setpoint in summer. At 24-25 ºC you live just as well.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"34px","fontWeight":"700"}},"textColor":"acento","fontFamily":"titulos"} -->
			<p class="has-acento-color has-text-color has-titulos-font-family" style="font-size:34px;font-weight:700"><?php esc_html_e( '2 visits', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
			<!-- wp:paragraph {"style":{"typography":{"fontSize":"16px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:16px"><?php esc_html_e( 'A year with the contract: one before the heat and one before the cold. It is what prevents the August breakdown.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
