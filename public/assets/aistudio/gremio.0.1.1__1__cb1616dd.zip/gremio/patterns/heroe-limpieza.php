<?php
/**
 * Title: Cleaning · Hero
 * Slug: gremio/heroe-limpieza
 * Categories: gremio-portadas
 * Description: First screen for cleaning. The hero was generated on 11/10/2026 in 16:9 with the professional on the right and the left clear: the one from the old batch was square and the wide version had the person centred, under the headline.
 * Keywords: cleaning, hero, cover, contract, home, office
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/hero-limpieza.jpg' ) ); ?>","dimRatio":80,"overlayColor":"tinta","isUserOverlayColor":true,"minHeight":620,"minHeightUnit":"px","contentPosition":"center left","align":"full","style":{"spacing":{"padding":{"top":"96px","bottom":"96px"}}}} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-center-left" style="padding-top:96px;padding-bottom:96px;min-height:620px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-80 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/hero-limpieza.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:group {"layout":{"type":"constrained","contentSize":"720px","justifyContent":"left"}} -->
	<div class="wp-block-group">
		<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px","letterSpacing":"0.08em","textTransform":"uppercase","fontWeight":"700"}},"textColor":"acento","fontFamily":"texto"} -->
		<p class="has-acento-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Cleaning · Homes, offices and communities', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:heading {"level":1,"textColor":"claro"} -->
		<h1 class="wp-block-heading has-claro-color has-text-color"><?php esc_html_e( 'The same cleaner, every time, for the hours you pay for.', 'gremio' ); ?></h1>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"19px"}},"textColor":"claro"} -->
		<p class="has-claro-color has-text-color" style="font-size:19px"><?php esc_html_e( 'Regular cleaning of homes, offices, entrance halls and stairwells. It is quoted by the hour, the same person does it every week and the day is changed without losing the clean if someone is off.', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:buttons -->
		<div class="wp-block-buttons">
			<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
			<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="#presupuesto"><?php esc_html_e( 'Ask for a quote', 'gremio' ); ?></a></div>
			<!-- /wp:button -->

			<!-- wp:button {"className":"is-style-outline","textColor":"claro","style":{"border":{"width":"2px","color":"var:preset|color|claro","radius":"999px"},"elements":{"link":{"color":{"text":"var:preset|color|claro"}}}}} -->
			<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-claro-color has-text-color has-border-color wp-element-button" style="border-color:var(--wp--preset--color--claro);border-width:2px;border-radius:999px" href="tel:+34900000000"><?php esc_html_e( 'Call now', 'gremio' ); ?></a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
		<p class="has-claro-color has-text-color" style="font-size:15px"><?php esc_html_e( 'No tie-in contract · Staff properly registered and insured · If someone is off, you are told and the clean is made up', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
