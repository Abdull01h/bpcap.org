<?php
/**
 * Title: Electrical work · Charging and self-consumption
 * Slug: gremio/moderna-electricidad
 * Categories: gremio-piezas
 * Description: Ink band with the four figures for what is in demand now (EV charger, days of work, certificate and lifespan of the solar panels), in the style of the efficiency band of air conditioning. The figures are examples for the demo.
 * Keywords: electrical work, charging, electric car, solar, self-consumption, figures
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"tinta","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull has-tinta-background-color has-background" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'What\'s in demand now', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","textColor":"claro"} -->
	<h2 class="wp-block-heading has-text-align-center has-claro-color has-text-color"><?php esc_html_e( 'Charging and self-consumption, with the numbers in front of you', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"38px","fontWeight":"700","lineHeight":"1.1"}},"textColor":"acento","fontFamily":"titulos"} -->
			<p class="has-text-align-center has-acento-color has-text-color has-titulos-font-family" style="font-size:38px;font-weight:700;line-height:1.1"><?php esc_html_e( '7.4 kW', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"textAlign":"center","style":{"typography":{"fontSize":"19px"}},"textColor":"claro"} -->
			<h3 class="wp-block-heading has-text-align-center has-claro-color has-text-color" style="font-size:19px"><?php esc_html_e( 'EV charger', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","textColor":"claro"} -->
			<p class="has-text-align-center has-claro-color has-text-color"><?php esc_html_e( 'With its own protections and RCD, and a separate meter if you want the charging to appear on its own bill.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"38px","fontWeight":"700","lineHeight":"1.1"}},"textColor":"acento","fontFamily":"titulos"} -->
			<p class="has-text-align-center has-acento-color has-text-color has-titulos-font-family" style="font-size:38px;font-weight:700;line-height:1.1"><?php esc_html_e( '1 day', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"textAlign":"center","style":{"typography":{"fontSize":"19px"}},"textColor":"claro"} -->
			<h3 class="wp-block-heading has-text-align-center has-claro-color has-text-color" style="font-size:19px"><?php esc_html_e( 'The fitting work', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","textColor":"claro"} -->
			<p class="has-text-align-center has-claro-color has-text-color"><?php esc_html_e( 'A garage with the supply close by is done in a day: wiring, protections and a tested start-up.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"38px","fontWeight":"700","lineHeight":"1.1"}},"textColor":"acento","fontFamily":"titulos"} -->
			<p class="has-text-align-center has-acento-color has-text-color has-titulos-font-family" style="font-size:38px;font-weight:700;line-height:1.1"><?php esc_html_e( '3 days', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"textAlign":"center","style":{"typography":{"fontSize":"19px"}},"textColor":"claro"} -->
			<h3 class="wp-block-heading has-text-align-center has-claro-color has-text-color" style="font-size:19px"><?php esc_html_e( 'The certificate', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","textColor":"claro"} -->
			<p class="has-text-align-center has-claro-color has-text-color"><?php esc_html_e( 'From the visit to the file number, with anything that needs fixing quoted and approved before we touch it.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"38px","fontWeight":"700","lineHeight":"1.1"}},"textColor":"acento","fontFamily":"titulos"} -->
			<p class="has-text-align-center has-acento-color has-text-color has-titulos-font-family" style="font-size:38px;font-weight:700;line-height:1.1"><?php esc_html_e( '25 years', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
			<!-- wp:heading {"level":3,"textAlign":"center","style":{"typography":{"fontSize":"19px"}},"textColor":"claro"} -->
			<h3 class="wp-block-heading has-text-align-center has-claro-color has-text-color" style="font-size:19px"><?php esc_html_e( 'Lifespan of the panels', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"align":"center","textColor":"claro"} -->
			<p class="has-text-align-center has-claro-color has-text-color"><?php esc_html_e( 'The inverter is replaced earlier, at around 10-12 years. We say it from day one: we don\'t sell an installation that won\'t pay for itself.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"36px"}},"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="margin-top:36px;font-size:18px"><?php esc_html_e( 'Before proposing anything we look at the home\'s actual consumption on the bills: if it doesn\'t add up, we say so.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"24px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:24px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Have it worked out for me', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->