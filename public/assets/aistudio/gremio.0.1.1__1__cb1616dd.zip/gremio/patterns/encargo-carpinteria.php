<?php
/**
 * Title: Carpentry · What it costs and how long it takes
 * Slug: gremio/encargo-carpinteria
 * Categories: gremio-piezas
 * Description: A quote per piece with its lead time next to it, which is what is specific to this trade (a made-to-measure piece does not come out in two days). The figures are examples for the demo: the carpenter who buys the theme puts in his own.
 * Keywords: carpentry, quote, lead times, prices, order
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"fondo","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull has-fondo-background-color has-background" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'What it costs and how long it takes, piece by piece', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'Examples of orders we have made, with the workshop lead time next to each one. The lead times are real: a made-to-measure door does not come out in two days.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"backgroundColor":"claro","style":{"spacing":{"margin":{"top":"36px"},"padding":{"top":"30px","bottom":"30px","left":"34px","right":"34px"}},"border":{"radius":"12px","width":"1px","color":"rgba(0,0,0,0.07)"}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.07);border-width:1px;border-radius:12px;margin-top:36px;padding-top:30px;padding-right:34px;padding-bottom:30px;padding-left:34px">
		<!-- wp:list -->
		<ul class="wp-block-list">
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Oak internal door, with ironmongery and varnished:</strong> 320 – 480 € · 2 weeks', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Made-to-measure wardrobe, with wooden doors:</strong> 180 – 320 €/m² of frontage · 3 weeks', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Wooden window with double glazing:</strong> from 260 € per leaf · 3 weeks', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Multi-layer oak flooring, laid:</strong> 45 – 70 €/m² · one week per room', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Restoration and varnishing of an old door:</strong> 90 – 140 € · 1 week', 'gremio' ) ); ?></li><!-- /wp:list-item -->
		</ul>
		<!-- /wp:list -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
		<p style="font-size:15px"><?php esc_html_e( 'Measuring at home is free and the price includes the ironmongery and the fitting. The quote is signed per piece, with its lead time next to it, and if something hidden appears when we take things apart (a crooked opening, a rotten beam) we stop, tell you and decide it with you.', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"28px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:28px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Book a measuring visit', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
