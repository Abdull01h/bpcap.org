<?php
/**
 * Title: Home page — Plumbing
 * Slug: gremio/portada-fontaneria
 * Categories: gremio-portadas
 * Description: Complete plumbing home page: hero, what we do, how a leak is traced, unclogging with an indicative price, what to do outside opening hours, why choose us, reviews and contact.
 * Keywords: home page, plumbing, start, trade, leaks, unclogging
 */
?>
<!-- wp:pattern {"slug":"gremio/heroe-fontaneria"} /-->

<!-- wp:pattern {"slug":"gremio/servicios-fontaneria"} /-->

<!-- wp:pattern {"slug":"gremio/localizar-fontaneria"} /-->

<!-- wp:pattern {"slug":"gremio/desatascos-fontaneria"} /-->

<!-- wp:pattern {"slug":"gremio/fuera-horario-fontaneria"} /-->

<!-- wp:pattern {"slug":"gremio/razones"} /-->

<!-- wp:pattern {"slug":"gremio/opiniones-fontaneria"} /-->

<!-- wp:pattern {"slug":"gremio/contacto"} /-->
