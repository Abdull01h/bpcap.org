<?php
/**
 * Title: Renovation · Services
 * Slug: gremio/servicios-reformas
 * Categories: gremio-piezas
 * Description: The six renovation jobs, with the same style and colours as the reasons band (no boxes). Includes what this trade has to say and hardly anyone does: licences and rubble, and that a single person coordinates the trades.
 * Keywords: renovation, services, full refurbishment, kitchen, bathroom, premises
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-2-color has-text-color" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'What we do', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'From the partition wall to the last skirting board, with one person in charge', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'Masonry, plumbing, electrical work and finishes: one person coordinates the trades, so you don\'t have to be the site foreman in your own home.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 20h18"/><path d="M5 20V6a1 1 0 0 1 1-1h12a1 1 0 0 1 1 1v14"/><path d="M9 20v-6h6v6"/><path d="M9 8h2M13 8h2"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Full home renovation', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'From floor to ceiling, with all the trades coordinated by us. You can live in the house during the work or leave it empty: your call.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v14"/><path d="M3 20h18"/><path d="M8 9h8"/><circle cx="10.5" cy="14" r="1"/><circle cx="14" cy="14" r="1"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Kitchens and bathrooms', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'The most requested renovation. Strip-out, plumbing, electrical work, tiling and fitting, with the handover date fixed from day one.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 4h10v8H4Z"/><path d="M9 12v8"/><path d="M15 8h5v5"/><path d="M15 13l5-5"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Masonry and partition walls', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Knocking down a partition wall, opening up a doorway or moving a door: with whatever permissions are needed and the rubble out the same day.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"36px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:36px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 5h18v14H3Z"/><path d="M3 10h18"/><path d="M9 10v9"/><path d="M15 5v14"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Flooring and tiling', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Levelling, waterproofing and laying. The flooring and tiles you choose, laid by the same team that did the work.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="12" height="9" rx="1.5"/><path d="M6 6h6M6 9h3"/><path d="M18 10v11"/><path d="M15 21h6"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'On-site electrical work and plumbing', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'New consumer unit, light points, sockets and water connections, with the electrical installation certificate and the installation tested at the end.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4"/><path d="M3 10h18v3H3Z"/><path d="M5 13v7h14v-7"/><path d="M10 20v-4h4v4"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Premises and offices', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Renovations to open a business, in phases and at night if needed, so the premises are ready on the day you said.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
