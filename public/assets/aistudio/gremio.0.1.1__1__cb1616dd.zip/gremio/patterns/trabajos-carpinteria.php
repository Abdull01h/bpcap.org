<?php
/**
 * Title: Carpentry · Jobs
 * Slug: gremio/trabajos-carpinteria
 * Categories: gremio-piezas
 * Description: Three orders already fitted (door, wardrobe and window) with the trade photos and their explanation. There is no before/after here because we do not have pairs of carpentry photos: the finished work is shown and what was done, without inventing before states.
 * Keywords: carpentry, jobs, gallery, door, wardrobe, window
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-2-color has-text-color" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Jobs', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'Three orders, three made-to-measure pieces', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'What you see here left the workshop with these measurements and these finishes. Not one piece comes from a catalogue.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"12px"}}} -->
			<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/carpinteria-puerta.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Made-to-measure oak internal door', 'gremio' ); ?>" style="border-radius:12px"/></figure>
			<!-- /wp:image -->
			<!-- wp:paragraph -->
			<p><?php echo wp_kses_post( __( '<strong>Oak internal door.</strong> Made to the exact size of the opening and fitted in a morning, with new beading and handle.', 'gremio' ) ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"12px"}}} -->
			<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/carpinteria-mueble.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Fitted wardrobe from floor to ceiling with sliding doors', 'gremio' ); ?>" style="border-radius:12px"/></figure>
			<!-- /wp:image -->
			<!-- wp:paragraph -->
			<p><?php echo wp_kses_post( __( '<strong>Fitted wardrobe.</strong> From floor to ceiling, with sliding doors and the inside laid out with the client present so everything fits.', 'gremio' ) ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:image {"sizeSlug":"large","style":{"border":{"radius":"12px"}}} -->
			<figure class="wp-block-image size-large has-custom-border"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/carpinteria-ventana.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Wooden window with double glazing', 'gremio' ); ?>" style="border-radius:12px"/></figure>
			<!-- /wp:image -->
			<!-- wp:paragraph -->
			<p><?php echo wp_kses_post( __( '<strong>Wooden window.</strong> Double glazing and new beading, with the same measurements as the old one so we touch neither the sill nor the paint.', 'gremio' ) ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->