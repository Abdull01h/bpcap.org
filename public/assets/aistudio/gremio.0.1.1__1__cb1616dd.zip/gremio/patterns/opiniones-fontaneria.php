<?php
/**
 * Title: Plumbing · Reviews
 * Slug: gremio/opiniones-fontaneria
 * Categories: gremio-piezas
 * Description: Three plumbing reviews (a leak traced without breaking more than needed, a blocked downpipe and the water heater change with zone taps), with name, neighbourhood and what was done. The faces are AI-generated placeholder photos: swap them for real customers before publishing.
 * Keywords: plumbing, reviews, testimonials
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/fontaneria-griferia.jpg' ) ); ?>","dimRatio":90,"overlayColor":"tinta","isUserOverlayColor":true,"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:88px;padding-bottom:88px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-90 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/fontaneria-griferia.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:heading {"textAlign":"center","textColor":"acento"} -->
	<h2 class="wp-block-heading has-text-align-center has-acento-color has-text-color"><?php esc_html_e( 'What customers say', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'Leaks, blockages and water heaters from this season, told by the people who called them.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"32px","left":"40px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“He traced the bathroom leak without breaking a single extra tile: he measured, marked the spot with a pencil and opened up a hand’s width. The next day he came back and closed it up, good as before.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-1.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Alba, a customer from Vallecas', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Alba R.</strong><br>Vallecas · leak traced', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“The kitchen downpipe had been blocking up for years. He brought the machine and the camera, showed us where the water was going and it hasn’t happened again since.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-2.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Tomás, a customer from La Elipa', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Tomás E.</strong><br>La Elipa · blocked downpipe', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“He changed our water heater in a morning and fitted a stopcock for each zone. Now, if the water has to be shut off, we’re not left unable to use the bathroom.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-3.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Mercedes, a customer from Hortaleza', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Mercedes P.</strong><br>Hortaleza · water heater and stopcocks', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div></div>
<!-- /wp:cover -->
