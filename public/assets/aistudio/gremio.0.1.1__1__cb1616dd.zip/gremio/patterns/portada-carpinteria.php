<?php
/**
 * Title: Home page — Carpentry
 * Slug: gremio/portada-carpinteria
 * Categories: gremio-portadas
 * Description: Complete carpentry home page: hero, what we do, three jobs with a photo, the workshop and the materials, what each piece costs and how long it takes, why choose us, reviews and contact.
 * Keywords: home page, carpentry, start, trade, wood
 */
?>
<!-- wp:pattern {"slug":"gremio/heroe-carpinteria"} /-->

<!-- wp:pattern {"slug":"gremio/servicios-carpinteria"} /-->

<!-- wp:pattern {"slug":"gremio/trabajos-carpinteria"} /-->

<!-- wp:pattern {"slug":"gremio/taller-carpinteria"} /-->

<!-- wp:pattern {"slug":"gremio/encargo-carpinteria"} /-->

<!-- wp:pattern {"slug":"gremio/razones"} /-->

<!-- wp:pattern {"slug":"gremio/opiniones-carpinteria"} /-->

<!-- wp:pattern {"slug":"gremio/contacto"} /-->
