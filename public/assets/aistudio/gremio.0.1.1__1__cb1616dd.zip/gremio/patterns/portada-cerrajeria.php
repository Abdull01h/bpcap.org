<?php
/**
 * Title: Home page — Locksmithing
 * Slug: gremio/portada-cerrajeria
 * Categories: gremio-portadas
 * Description: The complete locksmithing home page: hero, what we do, published rates, anti-scam notice, why choose us, reviews and contact. It composes the theme's pieces with this trade's content; the generic ones (reasons and contact) are called as they are, so the frame isn't duplicated.
 * Keywords: home page, locksmithing, start, trade
 */
?>
<!-- wp:pattern {"slug":"gremio/heroe-cerrajeria"} /-->

<!-- wp:pattern {"slug":"gremio/servicios-cerrajeria"} /-->

<!-- wp:pattern {"slug":"gremio/tarifas-cerrajeria"} /-->

<!-- wp:pattern {"slug":"gremio/aviso-cerrajeria"} /-->

<!-- wp:pattern {"slug":"gremio/razones"} /-->

<!-- wp:pattern {"slug":"gremio/opiniones-cerrajeria"} /-->

<!-- wp:pattern {"slug":"gremio/contacto"} /-->
