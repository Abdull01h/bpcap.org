<?php
/**
 * Title: Plumbing · How a leak is traced
 * Slug: gremio/localizar-fontaneria
 * Categories: gremio-piezas
 * Description: Specific to this trade: how a leak is located without digging up more than needed (asking questions, measuring section by section, looking with a camera and opening only the spot). Band with the photo of the repair and 90% ink overlay.
 * Keywords: plumbing, leak, tracing, camera, pressure
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/fontaneria-fuga.jpg' ) ); ?>","dimRatio":90,"overlayColor":"tinta","isUserOverlayColor":true,"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:88px;padding-bottom:88px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-90 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/fontaneria-fuga.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'How a leak is traced', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","textColor":"claro"} -->
	<h2 class="wp-block-heading has-text-align-center has-claro-color has-text-color"><?php esc_html_e( 'Opening up the whole wall isn\'t searching: it\'s giving up', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'These are the steps taken before touching a single tile. If a leak is traced properly, you open a handspan, not half a wall.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Ask before touching', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'If the water comes out hot, the leak is in the pipe; if it comes out cold and only when you use an appliance, it\'s in a drain. That question saves half the work.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Measure section by section', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'Each section is shut off with its valve and the pressure is checked: the gauge shows which one drops. That\'s how you know which two points it\'s between, even when nothing is visible.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Look with the camera and open only what\'s needed', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'The camera goes in through the access point and shows the state of the pipe inside. We open only where the spot is, repair it and leave it closed and tidy for the builder.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"top":"36px"}},"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="margin-top:36px;font-size:18px"><?php esc_html_e( 'And if it turns out dearer than what was said on the phone, we let you know before carrying on. No surprise invoices.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->
</div></div>
<!-- /wp:cover -->