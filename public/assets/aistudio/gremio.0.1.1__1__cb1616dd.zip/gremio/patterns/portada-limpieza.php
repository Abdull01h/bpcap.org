<?php
/**
 * Title: Home page — Cleaning
 * Slug: gremio/portada-limpieza
 * Categories: gremio-portadas
 * Description: Complete cleaning home page: hero, what we do, the three contracts with their hours, how it starts (and why the first visit is longer), what products are used to clean, why choose us, reviews and contact.
 * Keywords: home page, cleaning, start, trade, contracts, office
 */
?>
<!-- wp:pattern {"slug":"gremio/heroe-limpieza"} /-->

<!-- wp:pattern {"slug":"gremio/servicios-limpieza"} /-->

<!-- wp:pattern {"slug":"gremio/contratos-limpieza"} /-->

<!-- wp:pattern {"slug":"gremio/primera-visita-limpieza"} /-->

<!-- wp:pattern {"slug":"gremio/productos-limpieza"} /-->

<!-- wp:pattern {"slug":"gremio/razones"} /-->

<!-- wp:pattern {"slug":"gremio/opiniones-limpieza"} /-->

<!-- wp:pattern {"slug":"gremio/contacto"} /-->
