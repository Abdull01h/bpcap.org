<?php
/**
 * Title: Cleaning · Reviews
 * Slug: gremio/opiniones-limpieza
 * Categories: gremio-piezas
 * Description: Three cleaning reviews (a home with the same person for three years, an office with a task sheet and a building’s communal areas), with name, area and what was contracted. The faces are AI-generated placeholder photos: swap them for real customers before publishing.
 * Keywords: cleaning, reviews, testimonials
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/limpieza-suelo.jpg' ) ); ?>","dimRatio":90,"overlayColor":"tinta","isUserOverlayColor":true,"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:88px;padding-bottom:88px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-90 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/limpieza-suelo.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:heading {"textAlign":"center","textColor":"acento"} -->
	<h2 class="wp-block-heading has-text-align-center has-acento-color has-text-color"><?php esc_html_e( 'What customers say', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'Homes, offices and buildings we look after every week.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"32px","left":"40px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“She’s been coming on Tuesdays for three years and knows the house better than we do: she knows which drawer not to open and which plants need watering. She’s never missed a day.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-1.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Elena, a customer from Vicálvaro', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Elena G.</strong><br>Vicálvaro · home, weekly', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“They clean the office before we arrive and the task sheet is signed every day. In two years they haven’t missed a single job or let us down.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-2.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Óscar, the office manager', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Óscar R.</strong><br>Azca · office', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“The communal entrance and stairs hadn’t been properly mopped in months. Now the landing smells clean, you can see through the entrance windows and the task sheet is up on the noticeboard.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-3.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Chair of the Los Olivos residents’ community', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Comunidad Los Olivos</strong><br>Fuencarral · communal entrance and stairs', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div></div>
<!-- /wp:cover -->
