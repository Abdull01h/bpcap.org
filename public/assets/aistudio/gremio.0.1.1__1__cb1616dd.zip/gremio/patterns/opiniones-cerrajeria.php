<?php
/**
 * Title: Locksmithing · Reviews
 * Slug: gremio/opiniones-cerrajeria
 * Categories: gremio-piezas
 * Description: The locksmithing reviews, with name, neighbourhood and the job that was done (night opening, lock cylinder change, shop lock): the same band with photo, stars and face that the other trades use, with this trade’s content.
 * Keywords: locksmithing, reviews, testimonials
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/cerrajeria-urgencia.jpg' ) ); ?>","dimRatio":90,"overlayColor":"tinta","isUserOverlayColor":true,"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:88px;padding-bottom:88px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-90 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cerrajeria-urgencia.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:heading {"textAlign":"center","textColor":"acento"} -->
	<h2 class="wp-block-heading has-text-align-center has-acento-color has-text-color"><?php esc_html_e( 'What the neighbours say', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'Call-outs from this season, each one with its invoice. When we give you the price on the phone, that’s the price.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"32px","left":"40px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“I left my keys inside at half eleven at night. He gave me the price on the phone, arrived in twenty minutes and opened up without marking the door.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-1.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Marta, a customer from the Chamberí neighbourhood', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Marta R.</strong><br>Chamberí · night opening', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“He changed the lock cylinder at home and the one in the building entrance, with protected copy keys. He gave me an invoice with his tax ID and didn’t charge me for the call-out.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-2.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Andrés, owner of the bar La Esquina', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Andrés P.</strong><br>Tetuán · lock cylinder change', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" style="color:var(--wp--preset--color--acento)" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“The shop lock kept jamming every two weeks. He came, fixed it and told us what it would cost before touching anything.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-3.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Cristina, the building manager', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Cristina L.</strong><br>Alenza · shop lock', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div></div>
<!-- /wp:cover -->
