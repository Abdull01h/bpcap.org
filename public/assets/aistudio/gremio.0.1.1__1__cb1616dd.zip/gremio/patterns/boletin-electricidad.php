<?php
/**
 * Title: Electrical work · The certificate (CIE)
 * Slug: gremio/boletin-electricidad
 * Categories: gremio-piezas
 * Description: Specific to this trade: the electrical installation certificate explained (what it is, when it is needed, what is checked, how much it costs and how long it takes). The amounts are examples for the demo: the installer who buys the theme sets their own.
 * Keywords: electrical work, certificate, cie, certified, power, paperwork
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"fondo","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull has-fondo-background-color has-background" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'The electrical certificate: when it\'s needed and what it costs', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'It\'s the document the energy supplier asks for to get your electricity supply registered, raise the capacity, sell or rent. Without it, the installation can\'t be contracted even if it works.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:group {"backgroundColor":"claro","style":{"spacing":{"margin":{"top":"36px"},"padding":{"top":"30px","bottom":"30px","left":"34px","right":"34px"}},"border":{"radius":"12px","width":"1px","color":"rgba(0,0,0,0.07)"}},"layout":{"type":"constrained"}} -->
	<div class="wp-block-group has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.07);border-width:1px;border-radius:12px;margin-top:36px;padding-top:30px;padding-right:34px;padding-bottom:30px;padding-left:34px">
		<!-- wp:list -->
		<ul class="wp-block-list">
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>What it is:</strong> the certificate from an authorised installer stating that the installation complies with the regulations and can be contracted.', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>When it\'s needed:</strong> when registering the electricity supply, when raising the capacity, when selling or renting the flat and when finishing a renovation with a new installation.', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>What\'s checked:</strong> earthing, RCD, insulation, cable cross-section and that there are no joints outside a box. It\'s measured with instruments, not eyeballed.', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>Price and lead time (examples):</strong> inspection and certificate for a home, 120 – 260 € · about 3 days from the visit to the file number.', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>If something needs fixing:</strong> it\'s quoted separately and decided with you before we touch anything. We never invoice a repair you haven\'t approved.', 'gremio' ) ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php echo wp_kses_post( __( '<strong>What you get:</strong> your PDF copy and the file number, with the date of the inspection and what was measured.', 'gremio' ) ); ?></li><!-- /wp:list-item -->
		</ul>
		<!-- /wp:list -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
		<p style="font-size:15px"><?php esc_html_e( 'The certificate is issued in the account holder\'s name and with the capacity requested: if the capacity is changed later, it has to be processed again. We tell you beforehand so you don\'t pay twice.', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"28px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:28px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Have my installation checked', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->