<?php
/**
 * Title: Home page — Electrical Work
 * Slug: gremio/portada-electricidad
 * Categories: gremio-portadas
 * Description: Complete electrical work home page: hero, what we do, the electrical certificate (CIE) explained, inside the panel, EV charging and self-consumption with figures, why choose us, reviews and contact.
 * Keywords: home page, electrical work, start, trade, certificate, panel
 */
?>
<!-- wp:pattern {"slug":"gremio/heroe-electricidad"} /-->

<!-- wp:pattern {"slug":"gremio/servicios-electricidad"} /-->

<!-- wp:pattern {"slug":"gremio/boletin-electricidad"} /-->

<!-- wp:pattern {"slug":"gremio/cuadro-electricidad"} /-->

<!-- wp:pattern {"slug":"gremio/moderna-electricidad"} /-->

<!-- wp:pattern {"slug":"gremio/razones"} /-->

<!-- wp:pattern {"slug":"gremio/opiniones-electricidad"} /-->

<!-- wp:pattern {"slug":"gremio/contacto"} /-->
