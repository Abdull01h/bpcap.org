<?php
/**
 * Title: Renovation · Reviews
 * Slug: gremio/opiniones-reformas
 * Categories: gremio-piezas
 * Description: The renovation reviews, with name, neighbourhood and what was renovated (a bathroom, the bar’s premises without closing, a whole flat). Same band with photo, stars and face as the other trades.
 * Keywords: renovation, reviews, testimonials
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/obra-cocina.jpg' ) ); ?>","dimRatio":90,"overlayColor":"tinta","isUserOverlayColor":true,"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:88px;padding-bottom:88px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-90 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/obra-cocina.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:heading {"textAlign":"center","textColor":"acento"} -->
	<h2 class="wp-block-heading has-text-align-center has-acento-color has-text-color"><?php esc_html_e( 'What the neighbours say', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'Jobs from this season. The completion date is signed with the quote, and it’s met or you’re told.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"32px","left":"40px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“He renovated our bathroom in the ten days he said. He started at eight and finished at five, and when he was done he took the rubble away and left it clean.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-1.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Marta, a customer from the Chamberí neighbourhood', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Marta R.</strong><br>Chamberí · bathroom renovation', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“We renovated the whole bar without closing for a single day: he did the work in stages and at night. He kept the date he gave us in writing.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-2.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Andrés, owner of the bar La Esquina', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Andrés P.</strong><br>Tetuán · premises renovation', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<div class="gremio-estrellas" style="color:var(--wp--preset--color--acento)" role="img" aria-label="<?php esc_attr_e( 'Five stars out of five', 'gremio' ); ?>"><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg><svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="m12 2.6 2.9 6 6.6.9-4.8 4.6 1.2 6.5L12 17.5l-5.9 3.1 1.2-6.5L2.5 9.5l6.6-.9z"/></svg></div>
			<!-- /wp:html -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"17.5px"}},"textColor":"claro"} -->
			<p class="has-claro-color has-text-color" style="font-size:17.5px"><?php esc_html_e( '“An 80 m² flat with three trades and a single point of contact. He called us every week to say how it was going and what was next.”', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","verticalAlignment":"center"},"style":{"spacing":{"blockGap":"14px"}}} -->
			<div class="wp-block-group">
				<!-- wp:image {"width":56,"height":56,"sizeSlug":"thumbnail","className":"is-style-rounded","style":{"border":{"radius":"999px"}}} -->
				<figure class="wp-block-image size-thumbnail is-resized is-style-rounded"><img src="<?php echo esc_url( get_theme_file_uri( 'assets/img/cliente-3.jpg' ) ); ?>" alt="<?php esc_attr_e( 'Cristina, the building manager', 'gremio' ); ?>" width="56" height="56" style="border-radius:999px"/></figure>
				<!-- /wp:image -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
				<p class="has-claro-color has-text-color" style="font-size:15px"><?php echo wp_kses_post( __( '<strong>Cristina L.</strong><br>Alenza · whole flat', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div></div>
<!-- /wp:cover -->
