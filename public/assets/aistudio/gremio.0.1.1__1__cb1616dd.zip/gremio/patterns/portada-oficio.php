<?php
/**
 * Title: Home page — Trade (generic)
 * Slug: gremio/portada-oficio
 * Categories: gremio-portadas
 * Description: Complete home page for a trade with nothing of its own: hero, what we do, why choose us, reviews and contact. This is the one used when the trade doesn't have its own pieces yet (locksmithing, heating and air conditioning, painting and decorating, and carpentry do have them). The site's pages carry this reference and the plugin replaces it with the trade's.
 * Keywords: home page, start, trade, generic
 */
?>
<!-- wp:pattern {"slug":"gremio/heroe-oficio"} /-->

<!-- wp:pattern {"slug":"gremio/servicios-oficio"} /-->

<!-- wp:pattern {"slug":"gremio/razones"} /-->

<!-- wp:pattern {"slug":"gremio/opiniones"} /-->

<!-- wp:pattern {"slug":"gremio/contacto"} /-->
