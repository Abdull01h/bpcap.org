<?php
/**
 * Title: Cleaning · What we use and what we do not
 * Slug: gremio/productos-limpieza
 * Categories: gremio-piezas
 * Description: What people ask most about a cleaning company and almost no website answers: what products are used to clean and what is done with delicate materials. Band with the photo of the products and a 90% ink overlay.
 * Keywords: cleaning, products, allergies, materials, cloths
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/limpieza-bano.jpg' ) ); ?>","dimRatio":90,"overlayColor":"tinta","isUserOverlayColor":true,"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:88px;padding-bottom:88px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-90 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/limpieza-bano.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Products and tools', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","textColor":"claro"} -->
	<h2 class="wp-block-heading has-text-align-center has-claro-color has-text-color"><?php esc_html_e( 'What we clean your home with, and what we do not', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'It is the thing people ask most when they call and what almost no website answers. Four rules that do not get broken, even in a hurry.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'One cloth per area', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'Green for the bathroom, blue for the kitchen, yellow for dust. What has been on the toilet does not go on the worktop, not even with a change of water.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'No strong perfumes', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'Neutral soap and fragrance-free products in homes with allergies, babies or pets. And if you prefer your own, we use yours and note down which ones they are.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Careful with materials', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'No bleach on wood, marble or natural stone, and a soft scourer on glass-ceramic hobs and steel. Damage from a product used wrongly cannot be fixed afterwards.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Clean vacuum and mop', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'A new bag when it is due and a mop that is washed and changed for each home. A dirty tool leaves the floor worse than it was: starting there is throwing the work away.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div></div>
<!-- /wp:cover -->