<?php
/**
 * Title: Carpentry · Workshop and materials
 * Slug: gremio/taller-carpinteria
 * Categories: gremio-piezas
 * Description: What sets this trade apart: its own workshop, the timber and finishes you can choose, and that the piece is made in the workshop and fitted at home. Band with the photo of the workshop and a 90% ink overlay (light text on top).
 * Keywords: carpentry, workshop, timber, finishes, materials
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/carpinteria-taller.jpg' ) ); ?>","dimRatio":90,"overlayColor":"tinta","isUserOverlayColor":true,"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:88px;padding-bottom:88px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-90 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/carpinteria-taller.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'The workshop', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","textColor":"claro"} -->
	<h2 class="wp-block-heading has-text-align-center has-claro-color has-text-color"><?php esc_html_e( 'Real wood, and the person who works it is right here', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'There are no middlemen between your home and the workbench: the same person who measures is the one who cuts and fits it.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Our own workshop', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'The timber comes into our workshop and leaves fitted. We do not subcontract, so anything that does not line up is fixed the same day, not a week later.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Timber and finishes', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'Oak, beech, pine and veneered board. Varnish, lacquer or oil, with physical samples to choose at home in your living room light, not from a catalogue.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Made here, fitted at home', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'We bring the finished piece, protect the opening and fit it the same day. The shavings go back to the workshop: all we take from your home is sawdust.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div></div>
<!-- /wp:cover -->