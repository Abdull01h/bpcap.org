<?php
/**
 * Title: Electrical work · Inside the consumer unit
 * Slug: gremio/cuadro-electricidad
 * Categories: gremio-piezas
 * Description: Band with the photo of the open consumer unit and what is actually changed inside it (circuit breakers per circuit, RCD and measured earthing). 90% ink overlay: the text goes light on top.
 * Keywords: electrical work, consumer unit, rcd, circuit breaker, earthing
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/electricista-cuadro.jpg' ) ); ?>","dimRatio":90,"overlayColor":"tinta","isUserOverlayColor":true,"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:88px;padding-bottom:88px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-90 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/electricista-cuadro.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Inside the consumer unit', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","textColor":"claro"} -->
	<h2 class="wp-block-heading has-text-align-center has-claro-color has-text-color"><?php esc_html_e( 'Replacing the consumer unit isn\'t putting in a bigger one', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'It\'s splitting the home into circuits and protecting each one. What gets changed, and why:', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'One circuit breaker per circuit', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'Lights, sockets, kitchen, washing machine and air con, each with its own. When it trips, you can see in the consumer unit which circuit it is and why, without being left in the dark not knowing what has happened.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'RCD against leaks', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'It\'s what cuts the power before a fault gives you a shock. It\'s fitted and tested with the trip button and by measurement, not just "in and done".', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Earthing and cable sizes', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'Measured earthing and cables of the thickness each circuit calls for. It\'s the first thing the certificate looks at and what is most often missing in old flats: that\'s why it\'s checked before giving a price.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div></div>
<!-- /wp:cover -->