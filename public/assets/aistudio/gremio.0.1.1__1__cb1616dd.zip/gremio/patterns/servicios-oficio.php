<?php
/**
 * Title: Trade services (six, with icon)
 * Slug: gremio/servicios-oficio
 * Categories: gremio-piezas
 * Description: The six most requested things for the trade, each with its own icon and a "quote" next to it. This is the frame; the content per trade comes with the pieces of the plugin that goes with the theme, or is written by hand.
 * Keywords: services, grid, icons, trade
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull" style="padding-top:88px;padding-bottom:88px">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-2-color has-text-color" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'What we do', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'The six things we\'re asked for most', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'From your call to the visit, no surprises: what we tell you is what you pay.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M12 2.5c3.3 4 5.5 7 5.5 9.6A5.5 5.5 0 0 1 6.5 12C6.5 9.5 8.7 6.5 12 2.5Z"/><path d="M9.8 13.6a2.4 2.4 0 0 0 2.4 2.4"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Leaks and damp', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'We locate the leak without breaking more than needed and repair the spot that\'s causing it.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M6 20V6a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v14"/><path d="M4 20h16"/><path d="M10 8h4"/><path d="M10 12h4"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Taps and sanitaryware', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Replacing taps, cisterns, toilets and washbasins: the part and the labour hour, listed separately and in writing.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M12 3v6"/><path d="M8 9h8v4a4 4 0 0 1-4 4 4 4 0 0 1-4-4Z"/><path d="M10 21h4"/><path d="M12 17v4"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Blocked drains', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Sinks, soil stacks and inspection chambers. If we need the machine, we quote the price before taking it out.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"24px","left":"24px"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><rect x="5" y="3" width="14" height="18" rx="3"/><path d="M9 8h6"/><path d="M12 12v5"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Water heaters and boilers', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'You can\'t go without hot water: checking, repairing or replacing the water heater the same day.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M4 20h16"/><path d="M6 20V9l6-4 6 4v11"/><path d="M10 20v-6h4v6"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Full bathrooms', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Replacing the whole bathroom with the materials you choose and a fixed quote broken down in stages.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Blocks and premises', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Servicing under contract for communal entrances, offices and bars: a fixed visit and a monthly price.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
