<?php
/**
 * Title: Painting and decorating · Façades and residents' committees
 * Slug: gremio/fachada-pintura
 * Categories: gremio-piezas
 * Description: The façade band, with the photo of the painter on the scaffolding and a dark overlay (band with photo: the text goes light). It explains in three points what a residents' committee really worries about: the scaffolding, the price per square metre and being able to pay it in stages.
 * Keywords: painting and decorating, façade, residents committee, scaffolding
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/pintura-fachada.jpg' ) ); ?>","dimRatio":80,"overlayColor":"tinta","isUserOverlayColor":true,"contentPosition":"center left","align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}}} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-center-left" style="padding-top:88px;padding-bottom:88px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-80 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/pintura-fachada.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:group {"textColor":"claro","layout":{"type":"constrained","contentSize":"700px","justifyContent":"left"}} -->
	<div class="wp-block-group has-claro-color has-text-color">
		<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento","fontFamily":"texto"} -->
		<p class="has-acento-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Façades and residents\' committees', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:heading -->
		<h2 class="wp-block-heading"><?php esc_html_e( 'A façade is ruined by water, not by the years', 'gremio' ); ?></h2>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px"}}} -->
		<p style="font-size:18px"><?php esc_html_e( 'It is cleaned with a pressure washer, the cracks are opened up, sealed and finished with breathable paint. That way water stops coming in and the building looks cared for again.', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:list {"style":{"typography":{"fontSize":"17px"}}} -->
		<ul class="wp-block-list" style="font-size:17px">
			<!-- wp:list-item --><li><?php esc_html_e( 'Fencing, scaffolding and lifeline: no risk for anyone, not even for those walking underneath.', 'gremio' ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php esc_html_e( 'Quote by square metre of façade, with scaffolding and materials included in the price.', 'gremio' ); ?></li><!-- /wp:list-item -->
			<!-- wp:list-item --><li><?php esc_html_e( 'It can be done in stages, so the residents\' committee can pay as it can.', 'gremio' ); ?></li><!-- /wp:list-item -->
		</ul>
		<!-- /wp:list -->

		<!-- wp:buttons -->
		<div class="wp-block-buttons">
			<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
			<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Call now', 'gremio' ); ?></a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->
	</div>
	<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
