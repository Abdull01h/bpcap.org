<?php
/**
 * Title: Home page — Painting and Decorating
 * Slug: gremio/portada-pintura
 * Categories: gremio-portadas
 * Description: Complete painting and decorating home page: hero, what we do, before and after, quote by square metres, facades and communities, why choose us, reviews and contact. The generic pieces (reasons and contact) are called as they are, so the frame isn't duplicated.
 * Keywords: home page, painting, start, trade, painters
 */
?>
<!-- wp:pattern {"slug":"gremio/heroe-pintura"} /-->

<!-- wp:pattern {"slug":"gremio/servicios-pintura"} /-->

<!-- wp:pattern {"slug":"gremio/antes-despues-pintura"} /-->

<!-- wp:pattern {"slug":"gremio/presupuesto-pintura"} /-->

<!-- wp:pattern {"slug":"gremio/fachada-pintura"} /-->

<!-- wp:pattern {"slug":"gremio/razones"} /-->

<!-- wp:pattern {"slug":"gremio/opiniones-pintura"} /-->

<!-- wp:pattern {"slug":"gremio/contacto"} /-->
