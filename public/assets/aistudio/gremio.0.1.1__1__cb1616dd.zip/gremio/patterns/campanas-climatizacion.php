<?php
/**
 * Title: Heating and air conditioning · The two campaigns
 * Slug: gremio/campanas-climatizacion
 * Categories: gremio-piezas
 * Description: What makes the heating and air conditioning landing page different: the year split into two campaigns. In spring we install (when there is space and it is tested with real heat), in autumn we service it before the cold. With what each one includes.
 * Keywords: heating and air conditioning, campaigns, installation, servicing, service contract
 */
?>
<!-- wp:group {"align":"full","backgroundColor":"fondo","style":{"spacing":{"padding":{"top":"80px","bottom":"80px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull has-fondo-background-color has-background" style="padding-top:80px;padding-bottom:80px">
	<!-- wp:heading {"textAlign":"center"} -->
	<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'Two campaigns a year, so it is not all left to August', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'Air conditioning gets booked when the heat hits and heating when the cold arrives; the unit is installed and serviced beforehand. That way there are no waits or emergency call-outs.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"40px"},"blockGap":{"top":"28px","left":"28px"}}}} -->
	<div class="wp-block-columns" style="margin-top:40px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"backgroundColor":"claro","style":{"spacing":{"padding":{"top":"30px","bottom":"30px","left":"30px","right":"30px"}},"border":{"radius":"12px","width":"1px","color":"rgba(0,0,0,0.07)"}},"layout":{"type":"constrained"}} -->
			<div class="wp-block-group has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.07);border-width:1px;border-radius:12px;padding-top:30px;padding-right:30px;padding-bottom:30px;padding-left:30px">
				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
				<p class="has-acento-2-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Spring', 'gremio' ); ?></p>
				<!-- /wp:paragraph -->

				<!-- wp:heading {"level":3} -->
				<h3 class="wp-block-heading"><?php esc_html_e( 'Installation campaign', 'gremio' ); ?></h3>
				<!-- /wp:heading -->

				<!-- wp:paragraph -->
				<p><?php esc_html_e( 'Before the heat: we install in April and May, when there is space in the diary. The unit gets tested with real heat, not with the hope that it works in July.', 'gremio' ); ?></p>
				<!-- /wp:paragraph -->

				<!-- wp:list -->
				<ul class="wp-block-list">
					<!-- wp:list-item --><li><?php esc_html_e( 'Survey of size, orientation and insulation', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'Two unit options, with what each one costs', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'Installation in a day, with the wall left as it was', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'Start-up and a run-through of the remote', 'gremio' ); ?></li><!-- /wp:list-item -->
				</ul>
				<!-- /wp:list -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:group {"backgroundColor":"claro","style":{"spacing":{"padding":{"top":"30px","bottom":"30px","left":"30px","right":"30px"}},"border":{"radius":"12px","width":"1px","color":"rgba(0,0,0,0.07)"}},"layout":{"type":"constrained"}} -->
			<div class="wp-block-group has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.07);border-width:1px;border-radius:12px;padding-top:30px;padding-right:30px;padding-bottom:30px;padding-left:30px">
				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
				<p class="has-acento-2-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Autumn', 'gremio' ); ?></p>
				<!-- /wp:paragraph -->

				<!-- wp:heading {"level":3} -->
				<h3 class="wp-block-heading"><?php esc_html_e( 'Servicing campaign', 'gremio' ); ?></h3>
				<!-- /wp:heading -->

				<!-- wp:paragraph -->
				<p><?php esc_html_e( 'Before the cold: with the annual contract we check your heating and air conditioning over two visits, one per season. Without a contract, a one-off clean costs more and ends up being forgotten.', 'gremio' ); ?></p>
				<!-- /wp:paragraph -->

				<!-- wp:list -->
				<ul class="wp-block-list">
					<!-- wp:list-item --><li><?php esc_html_e( 'Cleaning and disinfecting filters and coils', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'Check of pressures and gas charge', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'A written report of what was checked', 'gremio' ); ?></li><!-- /wp:list-item -->
					<!-- wp:list-item --><li><?php esc_html_e( 'We remind you when it is due, not the other way round', 'gremio' ); ?></li><!-- /wp:list-item -->
				</ul>
				<!-- /wp:list -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"28px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:28px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Ask about the contract', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
