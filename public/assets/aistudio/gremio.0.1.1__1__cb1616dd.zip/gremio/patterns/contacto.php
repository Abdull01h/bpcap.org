<?php
/**
 * Title: Contact, opening hours and asking for a quote
 * Slug: gremio/contacto
 * Categories: gremio-piezas
 * Description: Contact details with their icons, the opening hours and the box where the quote form goes. The form itself is left to a plugin on purpose: the theme does not collect data. The fields the trade needs are already decided (name, phone, area, what you need, when, and how they would rather be contacted), and the privacy notice is written and ready.
 * Keywords: contact, quote, opening hours, form
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"80px","bottom":"80px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull" style="padding-top:80px;padding-bottom:80px">
	<!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"40px","left":"56px"}}}} -->
	<div class="wp-block-columns">
		<!-- wp:column {"width":"45%"} -->
		<div class="wp-block-column" style="flex-basis:45%">
			<!-- wp:heading {"level":2} -->
			<h2 class="wp-block-heading"><?php esc_html_e( 'Tell us what\'s wrong', 'gremio' ); ?></h2>
			<!-- /wp:heading -->

			<!-- wp:paragraph {"style":{"typography":{"fontSize":"18px"}}} -->
			<p style="font-size:18px"><?php esc_html_e( 'If it\'s a breakdown, call us: it\'s the quickest. If it\'s work that can be planned, leave us your details and we\'ll call you.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->

			<!-- wp:group {"style":{"spacing":{"margin":{"top":"28px"},"blockGap":"18px"}},"layout":{"type":"constrained"}} -->
			<div class="wp-block-group" style="margin-top:28px">
				<!-- wp:paragraph -->
				<p><?php echo wp_kses_post( __( '<strong>Phone</strong><br><a href="tel:+34900000000">900 000 000</a> · 24 h emergencies', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->

				<!-- wp:paragraph -->
				<p><?php echo wp_kses_post( __( '<strong>Email</strong><br><a href="mailto:hola@example.com">hola@example.com</a>', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->

				<!-- wp:paragraph -->
				<p><?php echo wp_kses_post( __( '<strong>Work area</strong><br>Madrid city and its surroundings: up to 25 km. Beyond that, we\'ll look into it.', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->

				<!-- wp:paragraph -->
				<p><?php echo wp_kses_post( __( '<strong>Opening hours</strong><br>Monday to Friday, 8:00 to 20:00. Saturdays, 9:00 to 14:00. Emergencies, every day.', 'gremio' ) ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column {"width":"55%"} -->
		<div class="wp-block-column" style="flex-basis:55%">
			<!-- wp:group {"className":"pieza-formulario","backgroundColor":"claro","style":{"spacing":{"padding":{"top":"32px","bottom":"32px","left":"32px","right":"32px"}},"border":{"radius":"14px","width":"1px","color":"rgba(0,0,0,0.08)"}},"layout":{"type":"constrained"}} -->
			<div class="wp-block-group pieza-formulario has-border-color has-claro-background-color has-background" style="border-color:rgba(0,0,0,0.08);border-width:1px;border-radius:14px;padding-top:32px;padding-right:32px;padding-bottom:32px;padding-left:32px">
				<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"22px"}}} -->
				<h3 class="wp-block-heading" style="font-size:22px"><?php esc_html_e( 'Ask for a quote', 'gremio' ); ?></h3>
				<!-- /wp:heading -->

				<!-- wp:group {"className":"gremio-hueco","layout":{"type":"constrained"}} -->
			<div class="wp-block-group gremio-hueco">
				<!-- wp:paragraph -->
				<p><?php esc_html_e( 'Your quote form goes here', 'gremio' ); ?></p>
				<!-- /wp:paragraph -->

				<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}}} -->
				<p style="font-size:15px"><?php esc_html_e( 'Gremio does not collect data on its own: add a form plugin (or your own form) and this box is ready to hold it.', 'gremio' ); ?></p>
				<!-- /wp:paragraph -->
			</div>
			<!-- /wp:group -->
			</div>
			<!-- /wp:group -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->