<?php
/**
 * Title: Plumbing · Out of hours
 * Slug: gremio/fuera-horario-fontaneria
 * Categories: gremio-piezas
 * Description: The plumbing emergency (what is attended at night and what is not) and the three moves that prevent bigger damage while the professional arrives. Band with the photo of the night emergency and 90% ink overlay.
 * Keywords: plumbing, emergency, night, holidays, leak
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/urgencia-noche.jpg' ) ); ?>","dimRatio":90,"overlayColor":"tinta","isUserOverlayColor":true,"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}}} -->
<div class="wp-block-cover alignfull" style="padding-top:88px;padding-bottom:88px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-90 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/urgencia-noche.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento","fontFamily":"texto"} -->
	<p class="has-text-align-center has-acento-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Out of hours', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:heading {"textAlign":"center","textColor":"claro"} -->
	<h2 class="wp-block-heading has-text-align-center has-claro-color has-text-color"><?php esc_html_e( 'What to do while we arrive', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}},"textColor":"claro"} -->
	<p class="has-text-align-center has-claro-color has-text-color" style="font-size:18px"><?php esc_html_e( 'We attend at night, on bank holidays and at weekends: what can\'t wait is a leak that\'s running or a blocked soil stack, not a dripping tap. While the plumber sets off, these three moves stop the damage getting worse.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Turn off the stopcock', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'It\'s usually by the entrance, in the bathroom or under the kitchen sink. If you can\'t find it, you\'ll be guided over the phone while the tools are being got ready: there\'s no need to wait for anyone to arrive.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Keep water away from the electrics', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'If the leak is near a socket, an extension lead or the fridge, switch off the RCD in the consumer unit before touching anything. It\'s not overreacting: it\'s the first thing we ask over the phone.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}},"textColor":"acento"} -->
			<h3 class="wp-block-heading has-acento-color has-text-color" style="font-size:20px"><?php esc_html_e( 'Don\'t force the blockage', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph {"textColor":"claro"} -->
			<p class="has-claro-color has-text-color"><?php esc_html_e( 'Wire rods and off-the-shelf chemicals break the seal and push the blockage further in. It\'s the breakdown that then costs twice as much, and the one you can see coming as soon as you call in the morning.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"},"style":{"spacing":{"margin":{"top":"36px"}}}} -->
	<div class="wp-block-buttons" style="margin-top:36px">
		<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
		<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="tel:+34900000000"><?php esc_html_e( 'Call the emergency line', 'gremio' ); ?></a></div>
		<!-- /wp:button -->
	</div>
	<!-- /wp:buttons -->
</div></div>
<!-- /wp:cover -->