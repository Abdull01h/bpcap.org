<?php
/**
 * Title: Electrical work · Hero
 * Slug: gremio/heroe-electricidad
 * Categories: gremio-portadas
 * Description: First screen for electrical work. The photo was generated on 11/10/2026 in 16:9 (the ones from the old batch were square and vertical, no good for a wide band): an electrician working on the consumer unit, with the left side free for the headline.
 * Keywords: electrical work, hero, cover, consumer unit, certificate
 */
?>
<!-- wp:cover {"url":"<?php echo esc_url( get_theme_file_uri( 'assets/img/hero-electricidad.jpg' ) ); ?>","dimRatio":80,"overlayColor":"tinta","isUserOverlayColor":true,"minHeight":620,"minHeightUnit":"px","contentPosition":"center left","align":"full","style":{"spacing":{"padding":{"top":"96px","bottom":"96px"}}}} -->
<div class="wp-block-cover alignfull has-custom-content-position is-position-center-left" style="padding-top:96px;padding-bottom:96px;min-height:620px"><span aria-hidden="true" class="wp-block-cover__background has-tinta-background-color has-background-dim-80 has-background-dim"></span><img class="wp-block-cover__image-background" alt="" src="<?php echo esc_url( get_theme_file_uri( 'assets/img/hero-electricidad.jpg' ) ); ?>" data-object-fit="cover"/><div class="wp-block-cover__inner-container">
	<!-- wp:group {"layout":{"type":"constrained","contentSize":"720px","justifyContent":"left"}} -->
	<div class="wp-block-group">
		<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px","letterSpacing":"0.08em","textTransform":"uppercase","fontWeight":"700"}},"textColor":"acento","fontFamily":"texto"} -->
		<p class="has-acento-color has-text-color has-texto-font-family" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'Electrical work · Certificate, consumer unit and faults', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:heading {"level":1,"textColor":"claro"} -->
		<h1 class="wp-block-heading has-claro-color has-text-color"><?php esc_html_e( 'Consumer units, certificates and faults, all done to code.', 'gremio' ); ?></h1>
		<!-- /wp:heading -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"19px"}},"textColor":"claro"} -->
		<p class="has-claro-color has-text-color" style="font-size:19px"><?php esc_html_e( 'We renew consumer units and protective devices, process the electrical installation certificate (CIE), fit new outlets, EV charge points and solar self-consumption. Authorised installer and work checked with instruments, not by eye.', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->

		<!-- wp:buttons -->
		<div class="wp-block-buttons">
			<!-- wp:button {"backgroundColor":"acento","textColor":"tinta"} -->
			<div class="wp-block-button"><a class="wp-block-button__link has-tinta-color has-acento-background-color has-text-color has-background wp-element-button" href="#presupuesto"><?php esc_html_e( 'Ask for a quote', 'gremio' ); ?></a></div>
			<!-- /wp:button -->

			<!-- wp:button {"className":"is-style-outline","textColor":"claro","style":{"border":{"width":"2px","color":"var:preset|color|claro","radius":"999px"},"elements":{"link":{"color":{"text":"var:preset|color|claro"}}}}} -->
			<div class="wp-block-button is-style-outline"><a class="wp-block-button__link has-claro-color has-text-color has-border-color wp-element-button" style="border-color:var(--wp--preset--color--claro);border-width:2px;border-radius:999px" href="tel:+34900000000"><?php esc_html_e( 'Call now', 'gremio' ); ?></a></div>
			<!-- /wp:button -->
		</div>
		<!-- /wp:buttons -->

		<!-- wp:paragraph {"style":{"typography":{"fontSize":"15px"}},"textColor":"claro"} -->
		<p class="has-claro-color has-text-color" style="font-size:15px"><?php esc_html_e( 'Authorised installer · Certificate filed with the utility · The installation is measured and checked before we sign it off', 'gremio' ); ?></p>
		<!-- /wp:paragraph -->
	</div>
	<!-- /wp:group -->
</div></div>
<!-- /wp:cover -->
