<?php
/**
 * Title: Heating and Air Conditioning · Services
 * Slug: gremio/servicios-climatizacion
 * Categories: gremio-piezas
 * Description: The six heating and air conditioning jobs, with the usual frame (no boxes and the same colours as the reasons band (icons in the dark accent)) and the content of this trade: install, service, repair and heat and cool premises.
 * Keywords: heating, services, split unit, ducted system, heat pump, servicing
 */
?>
<!-- wp:group {"align":"full","style":{"spacing":{"padding":{"top":"88px","bottom":"88px"}}},"layout":{"type":"constrained","wideSize":"1140px"}} -->
<div class="wp-block-group alignfull" style="padding-top:88px;padding-bottom:88px">
<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"15px","fontWeight":"700","letterSpacing":"0.08em","textTransform":"uppercase"}},"textColor":"acento-2","fontFamily":"texto"} -->
<p class="has-text-align-center has-acento-2-color has-text-color" style="font-size:15px;font-weight:700;letter-spacing:0.08em;text-transform:uppercase"><?php esc_html_e( 'What we do', 'gremio' ); ?></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center"><?php esc_html_e( 'We install, service and repair', 'gremio' ); ?></h2>
	<!-- /wp:heading -->

	<!-- wp:paragraph {"align":"center","style":{"typography":{"fontSize":"18px"}}} -->
	<p class="has-text-align-center" style="font-size:18px"><?php esc_html_e( 'Installing is half the trade; the other half is keeping what you already have running and not wasting money.', 'gremio' ); ?></p>
	<!-- /wp:paragraph -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"48px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:48px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="6" rx="2"/><path d="M6 14v4"/><path d="M10 14v5"/><path d="M14 14v4"/><path d="M18 14v5"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Split unit installation', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'We choose the unit by square metres and orientation, not by what\'s in the warehouse. Up and running and a walkthrough of the remote, the same day.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 8h16"/><path d="M4 12h16"/><path d="M4 16h10"/><path d="M19 15v4"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Ducted air', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Tidy work and vents where they won\'t get in the way, with the route decided before we cut into the false ceiling.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 4h12v6a6 6 0 0 1-12 0Z"/><path d="M12 16v4"/><path d="M9 20h6"/><path d="M9 7h6"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Servicing under contract', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Two visits a year: cleaning filters and coils, checking gas and pressures, and a written report of what\'s been done.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->

	<!-- wp:columns {"style":{"spacing":{"margin":{"top":"36px"},"blockGap":{"top":"36px","left":"36px"}}}} -->
	<div class="wp-block-columns" style="margin-top:36px">
		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 3v6"/><path d="M8 9h8v5a4 4 0 0 1-8 0Z"/><path d="M10 21h4"/><path d="M12 18v3"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Repair and gas recharge', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'First we trace the leak and fix it; recharging without finding where it\'s escaping is paying twice for the same thing.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="12" cy="12" r="3.2"/><path d="M12 3v3"/><path d="M12 18v3"/><path d="M4.6 7.5l2.6 1.6"/><path d="M16.8 14.9l2.6 1.6"/><path d="M19.4 7.5l-2.6 1.6"/><path d="M7.2 14.9l-2.6 1.6"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Heat pump and underfloor heating', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Heating and hot water with a heat pump: lower bills than a boiler and no building work in the house.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->

		<!-- wp:column -->
		<div class="wp-block-column">
			<!-- wp:html -->
			<svg width="38" height="38" viewBox="0 0 24 24" fill="none" stroke="currentColor" style="color:var(--wp--preset--color--acento-2)" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20h16"/><path d="M6 20V9l6-4 6 4v11"/><path d="M10 20v-6h4v6"/></svg>
			<!-- /wp:html -->
			<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"20px"}}} -->
			<h3 class="wp-block-heading" style="font-size:20px"><?php esc_html_e( 'Premises and offices', 'gremio' ); ?></h3>
			<!-- /wp:heading -->
			<!-- wp:paragraph -->
			<p><?php esc_html_e( 'Bars, offices and shops: units sized for the people coming and going, with servicing kept up to date.', 'gremio' ); ?></p>
			<!-- /wp:paragraph -->
		</div>
		<!-- /wp:column -->
	</div>
	<!-- /wp:columns -->
</div>
<!-- /wp:group -->
