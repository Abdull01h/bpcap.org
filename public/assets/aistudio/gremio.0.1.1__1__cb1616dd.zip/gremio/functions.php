<?php
/**
 * Gremio · lo que el tema hace al cargar.
 *
 * Tres cosas, y ninguna más:
 *   1. Cargar la hoja de estilo del tema. Un tema de bloques NO la carga solo: sin esto, lo que hay en
 *      style.css no llega a la página (ni el arreglo del hueco entre secciones, ni el estilo del formulario).
 *   2. Quitar del tema la tienda. Gremio es información y contacto: no lleva WooCommerce, ni carrito, ni
 *      cuenta de cliente. WooCommerce inyecta el carrito pequeño y el icono de cuenta dentro de la cabecera
 *      por su cuenta (bloques enganchados), aunque el tema no lo llame: se desenganchan aquí.
 *   3. Nada de peticiones a terceros ni de JavaScript propio.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * La hoja de estilo del tema, con la fecha del fichero como versión (así no hay caché vieja al editar).
 */
function gremio_estilos() {
	$ruta = get_theme_file_path( 'style.css' );
	wp_enqueue_style( 'gremio-estilo', get_stylesheet_uri(), array(), file_exists( $ruta ) ? filemtime( $ruta ) : '0.1.0' );
}
add_action( 'wp_enqueue_scripts', 'gremio_estilos' );

/**
 * Fuera la tienda de la cabecera: el carrito pequeño y el icono de cuenta que WooCommerce engancha solo.
 */
function gremio_sin_tienda( $bloques_enganchados, $posicion = '', $bloque_ancla = '', $contexto = null ) {
	if ( ! is_array( $bloques_enganchados ) ) {
		return $bloques_enganchados;
	}
	return array_values( array_diff( $bloques_enganchados, array(
		'woocommerce/mini-cart',
		'woocommerce/customer-account',
		'woocommerce/mini-cart-contents',
	) ) );
}
add_filter( 'hooked_block_types', 'gremio_sin_tienda', 20, 4 );

/**
 * Y que no se ofrezca lo de la tienda en el panel de bloques (patrones y plantillas de WooCommerce).
 */
function gremio_sin_tienda_en_el_editor( $tipos ) {
	foreach ( $tipos as $clave => $tipo ) {
		if ( isset( $tipo->name ) && str_starts_with( (string) $tipo->name, 'woocommerce/' ) ) {
			unset( $tipos[ $clave ] );
		}
	}
	return $tipos;
}
add_filter( 'get_block_templates', 'gremio_sin_tienda_en_el_editor', 20 );

/**
 * Las traducciones del tema, desde la carpeta `languages/`.
 *
 * Los textos de los patrones van envueltos en gettext con el dominio `gremio`: sin esta llamada, WordPress
 * sabe el dominio (está en la cabecera de style.css) pero no mira en la carpeta del tema.
 */
function gremio_carga_idiomas() {
	load_theme_textdomain( 'gremio', get_template_directory() . '/languages' );
}
add_action( 'after_setup_theme', 'gremio_carga_idiomas' );
