=== Gremio ===
Contributors: farowp
Requires at least: 6.5
Tested up to: 7.1
Requires PHP: 8.1
Stable tag: 0.1.1
License: GNU General Public License v2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Text Domain: gremio
Tags: one-column, full-site-editing, block-patterns, block-styles, wide-blocks, custom-colors, custom-logo, custom-menu, editor-style, featured-images, translation-ready

Gremio WordPress Theme, Copyright 2026 FaroWP
Gremio is distributed under the terms of the GNU General Public License v2 or later.

A block theme for the trades that visit your home: plumbing, electrical, cleaning, locksmithing, heating and air conditioning, renovation, painting and carpentry.

== Description ==

Gremio is a block theme (full site editing) built for tradespeople who work in people's homes. It is made for the moment someone has a leak and looks for a phone number on their phone: no JavaScript, no third-party requests, the phone always in sight and everything measured for reading on a small screen.

Eight trades, one theme. Each trade has its own home page pattern, with the structure that trade really needs:

* **Plumbing** — leaks traced before anything is opened up, blocked drains with published guide prices, out-of-hours emergencies.
* **Electrical** — consumer units and RCDs, the electrical installation certificate explained, EV chargers and solar self-consumption.
* **Cleaning** — the three ways to hire (home, office, communal building), how the hours are worked out and what products are used.
* **Locksmithing** — 24/7 call-outs, prices published per service and an anti-scam warning.
* **Heating and air conditioning** — installation and servicing as two separate jobs, efficiency figures and two seasonal campaigns.
* **Renovation** — before-and-after work, the stages and the lead times, itemised quotes with measurements.
* **Painting and decorating** — before and after by room, quotes by the square metre and façade work.
* **Carpentry** — made-to-measure work, the workshop and materials, and how long an order takes.

Eight style variations are included (`styles/`), one per trade: pick one under Appearance → Editor → Styles and the whole theme is repainted, patterns included, without touching a single file.

The demo content is honest by design: prices are published as examples and say so, the trades say what they will not do, and the testimonial photos are AI-generated demo faces that must be replaced with real customers before going live.

**Requirements**

* No JavaScript and no external requests: fonts are bundled in the theme.
* The contact pattern leaves an empty box where the quote form goes. The theme does not collect data on its own: the form is left to a plugin, and the fields the trade needs and the privacy notice are written and ready to use. Any form plugin from the WordPress.org directory will fit.

== Installation ==

1. In your WordPress dashboard, go to Appearance → Themes → Add New → Upload Theme and choose the `gremio.zip` file.
2. Activate the theme.
3. Go to Appearance → Editor to edit the header, the footer and the patterns, and Appearance → Editor → Styles to pick one of the eight trade variations.
4. Set the phone number and the email address in the header and footer patterns, and in the quote forms.

== Copyright ==

Gremio is distributed under the terms of the GNU General Public License v2 or later.

This theme bundles the following third-party resources:

* **Quicksand** font — Copyright 2011 The Quicksand Project Authors, licensed under the SIL Open Font License 1.1 (https://scripts.sil.org/OFL). Files: `assets/fonts/quicksand-latin.woff2`, `assets/fonts/quicksand-latin-ext.woff2`.
* **Montserrat** font — Copyright 2011 The Montserrat Project Authors, licensed under the SIL Open Font License 1.1 (https://scripts.sil.org/OFL). Files: `assets/fonts/montserrat-latin.woff2`, `assets/fonts/montserrat-latin-ext.woff2`.

Image credits: all photographs in `assets/img/` are original works created for FaroWP with an AI image service and are released under the same license as the theme (GNU General Public License v2 or later). The three faces shown in the testimonials are AI-generated demo images: they are not real people and must be replaced before publishing a real website.

All other code and content is Copyright 2026 FaroWP and licensed under the GNU General Public License v2 or later.

== Changelog ==

= 0.1.0 =
* First release: eight trades, eight style variations, twenty-odd patterns per trade, four templates plus the blog ones, and the theme translated (Spanish translation included under `languages/`).
